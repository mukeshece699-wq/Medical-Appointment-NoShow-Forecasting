# Medical Appointment No-Show Prediction & Demand Forecasting

Mini-project implementing the supplied specification: EDA, missing-value handling, feature engineering, three classification algorithms, three demand-regression algorithms, model evaluation, saved Joblib models, and a two-tab Streamlit app.

## Dataset
Download the project dataset from the link given in the project PDF and place the CSV inside `data/raw/`. The PDF describes 109,593 rows x 26 columns with target `no_show` and continuous date field `appointment_date_continuous`.

## Setup
```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
pip install -r requirements.txt
python src/eda.py
python src/train_classifier.py
python src/train_forecast.py
streamlit run app.py
```

## Models
Classification: Logistic Regression, Random Forest, XGBoost (when available). Selection uses ROC-AUC; F1, precision, recall and confusion matrix are recorded.

Demand forecasting: Ridge, Random Forest Regressor, Gradient Boosting Regressor with chronological 80/20 split and lag/calendar features. MAE, RMSE, MAPE and R2 are recorded.

## Targets from assignment
Classification: F1 > 0.70 and ROC-AUC > 0.75. Forecasting: MAPE < 20% and R2 > 0.65. These are targets, not claimed results. Actual results are generated only from the supplied dataset.

## GitHub submission
Upload all code files to a GitHub repository. Do not upload private/sensitive data or credentials. Submit the repository homepage URL as Backend Source Code.
