import pandas as pd, numpy as np
DATE='appointment_date_continuous'; TARGET='no_show'
def clean(df):
 d=df.copy(); d.columns=[c.strip() for c in d.columns]
 if DATE in d: d[DATE]=pd.to_datetime(d[DATE],errors='coerce')
 if TARGET in d:
  d[TARGET]=d[TARGET].astype(str).str.strip().str.lower().map({'yes':1,'no':0,'1':1,'0':0,'true':1,'false':0})
 return d
def add_features(d):
 d=d.copy()
 if DATE in d:
  d['year']=d[DATE].dt.year;d['month']=d[DATE].dt.month;d['dayofweek']=d[DATE].dt.dayofweek;d['day']=d[DATE].dt.day;d['is_weekend']=d[DATE].dt.dayofweek.isin([5,6]).astype(int)
 return d
