import pandas as pd,matplotlib.pyplot as plt,seaborn as sns
from pathlib import Path
from common import clean,TARGET,DATE
p=next(Path('data/raw').glob('*.csv'));d=clean(pd.read_csv(p));print(d.shape);print(d.isna().mean().sort_values(ascending=False).head(15));print(d[TARGET].value_counts(normalize=True,dropna=False));
if TARGET in d:
 sns.countplot(x=d[TARGET]);plt.title('No-show target distribution');plt.tight_layout();plt.savefig('outputs/plots/no_show_distribution.png');plt.close()
if DATE in d:
 z=d.groupby(DATE).size();z.plot(figsize=(10,4),title='Daily appointment demand');plt.tight_layout();plt.savefig('outputs/plots/daily_demand.png');plt.close()
