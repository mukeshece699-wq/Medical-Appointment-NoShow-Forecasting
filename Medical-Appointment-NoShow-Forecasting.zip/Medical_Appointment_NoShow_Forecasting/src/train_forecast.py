import pandas as pd,numpy as np,joblib,json
from pathlib import Path
from sklearn.metrics import mean_absolute_error,mean_squared_error,r2_score
from sklearn.ensemble import RandomForestRegressor,GradientBoostingRegressor
from sklearn.linear_model import Ridge
from common import clean,DATE
p=next(Path('data/raw').glob('*.csv'));d=clean(pd.read_csv(p)).dropna(subset=[DATE]).sort_values(DATE);daily=d.groupby(DATE).size().rename('y').to_frame();daily=daily.asfreq('D',fill_value=0)
for lag in [1,7,14,28]:daily[f'lag{lag}']=daily.y.shift(lag)
daily['dow']=daily.index.dayofweek;daily['month']=daily.index.month;daily['roll7']=daily.y.shift(1).rolling(7).mean();daily=daily.dropna();cut=int(len(daily)*.8);tr,te=daily.iloc[:cut],daily.iloc[cut:];cols=[c for c in daily if c!='y'];mods={'ridge':Ridge(alpha=1),'random_forest':RandomForestRegressor(n_estimators=300,random_state=42,n_jobs=-1),'gradient_boosting':GradientBoostingRegressor(random_state=42)};rows=[];best=None
for n,m in mods.items():
 m.fit(tr[cols],tr.y);pr=m.predict(te[cols]);mae=mean_absolute_error(te.y,pr);rmse=mean_squared_error(te.y,pr)**.5;mape=np.mean(np.abs((te.y-pr)/np.maximum(te.y,1)))*100;r2=r2_score(te.y,pr);r={'model':n,'MAE':mae,'RMSE':rmse,'MAPE':mape,'R2':r2};rows.append(r);print(r)
 if best is None or mape<best[0]:best=(mape,m,n)
joblib.dump({'model':best[1],'features':cols,'history':daily[['y']].tail(28)},'models/demand_forecaster.joblib');Path('outputs/metrics/forecast.json').write_text(json.dumps(rows,indent=2));print('BEST',best[2])
