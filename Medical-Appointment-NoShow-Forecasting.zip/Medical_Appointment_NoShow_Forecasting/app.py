import streamlit as st,pandas as pd,numpy as np,joblib
st.set_page_config(page_title='Medical Appointment Analytics',layout='wide');st.title('Medical Appointment No-Show & Demand Forecasting')
t1,t2=st.tabs(['No-show predictor','Demand forecaster'])
with t1:
 st.subheader('No-show risk')
 st.info('Model input fields must match the training CSV. For robust evaluation, run training first.')
 up=st.file_uploader('Upload one-row appointment CSV',type='csv')
 if up and st.button('Predict risk'):
  try:
   m=joblib.load('models/no_show_classifier.joblib');x=pd.read_csv(up);p=float(m.predict_proba(x)[:,1][0]);st.metric('No-show probability',f'{p:.1%}');st.progress(min(max(p,0),1))
  except Exception as e:st.error(str(e))
with t2:
 st.subheader('Daily demand forecasting')
 st.write('The saved forecaster uses chronological features and lag history. Run `python src/train_forecast.py` after adding the project dataset.')
 st.caption('Operational planning aid only. Predictions should be reviewed before staffing decisions.')
